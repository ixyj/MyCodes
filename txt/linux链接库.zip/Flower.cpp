#include <iostream>
#include "Flower.h"
using namespace std;


CFlower *GetGameObject(void)
{
        return(new CFlower());
}

int CFlower::Initialize(void)
{
        std::cout << "Initialize()" << std::endl;
        return(0);
}

int CFlower::Load(void)
{
        std::cout << "Load()" << std::endl;
        return(0);
}

int CFlower::Handle(void)
{
        std::cout << "Handle()" << std::endl;
        return(0);
}
