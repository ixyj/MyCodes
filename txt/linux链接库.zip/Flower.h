#ifndef __Flower_h__
#define __Flower_h__

class CFlower
{
public:
        virtual int Initialize(void);
        virtual int Load(void);
        virtual int Handle(void);
};

extern "C" CFlower *GetGameObject(void);

#endif
