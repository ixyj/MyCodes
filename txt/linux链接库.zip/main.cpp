
#include <iostream>
#include <dlfcn.h>

#include "Flower.h"
using namespace std;


int main(int argc, char** argv)
{
        void *GameLib = dlopen("./Flower.so", RTLD_LAZY);
        const char *dlError = dlerror();
         if (dlError)
        {
                std::cout << "dlopen error!" << dlError << std::endl;
                return(-1);
        }
        CFlower *(*pGetGameObject)(void);
        pGetGameObject = (CFlower *(*)(void))dlsym(GameLib, "GetGameObject");
        dlError = dlerror();
        if (dlError)
        {
                std::cout << "dlsym error!" << dlError << std::endl;
                return(-1);
        }
        CFlower *pGame = (*pGetGameObject)();
        pGame->Initialize();
        pGame->Load();
        pGame->Handle();
        delete pGame;
        dlclose(GameLib);
}
