// BaQueenDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"
#include "RoundButton.h"
#include "Game.h"

// CBaQueenDlg �Ի���
class CBaQueenDlg : public CDialog
{
// ����
public:
	CBaQueenDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_BAQUEEN_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()


private:
	CMyCDC m_qp;
	CMyCDC m_qiziNormal;
	CMyCDC m_qiziDead;
	CMyCDC m_qiziMask;
	CMyCDC m_cdc;

	CGame m_game;

	CRoundButton m_btnStart;
	CRoundButton m_btnExit;
	CRoundButton m_btnRet;
	CStatic m_info;

protected:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnBnClickedReturn();
	afx_msg void OnBnClickedButtonStart();

public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
