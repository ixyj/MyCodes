#include "StdAfx.h"
#include "Game.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

CGame::CGame(void)
{
	InitGame();
}

CGame::CGame(CDC* pDC, CMyCDC* pQP, CMyCDC* pQiziNormal, CMyCDC* pQiziDead, CMyCDC* pQiziMask)
{
	SetDC(pDC, pQP, pQiziNormal, pQiziDead, pQiziMask);
}

CGame::~CGame(void)
{
}

void CGame::InitGame(void)
{
	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)
			m_map[i][j] = kTypeNone;

	m_bNormal = true;

	m_curPosition.nx = 0;
	m_curPosition.ny = 0;

}

void CGame::Draw(void)
{
	CSize size = m_pQP->GetSize();
	m_pDC->BitBlt(0, 0,size.cx,size.cy, m_pQP, 0, 0, SRCCOPY);//������

	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)
		{
			if (m_map[i][j] == kTypeNormal) 
			{
				m_pDC->BitBlt(i*34+8,j*34+4,32,32,m_pQiziMask,0,0,MERGEPAINT);
				m_pDC->BitBlt(i*34+8,j*34+4,32,32,m_pQiziNormal,0,0,SRCAND);
			}
			else if (m_map[i][j] == kTypeDead)
			{
				m_pDC->BitBlt(i*34+8,j*34+4,32,32,m_pQiziMask,0,0,MERGEPAINT);
				m_pDC->BitBlt(i*34+8,j*34+4,32,32,m_pQiziDead,0,0,SRCAND);
			}
		}
}

void CGame::SetDC(CDC* pDC, CMyCDC* pQP, CMyCDC* pQiziNormal, CMyCDC* pQiziDead, CMyCDC* pQiziMask)
{
	m_pDC = pDC;
	m_pQP = pQP;
	m_pQiziNormal = pQiziNormal;
	m_pQiziDead = pQiziDead;
	m_pQiziMask = pQiziMask;
}
bool CGame::DownQiZi(int nX, int nY)
{
	if (nX < 0 || nX > 7 || nY < 0 || nY > 7)
		return false;

	DrawQiZi(nX, nY);
	
	bool bRet = PutQiZiAndJudge(nX, nY);

	m_curPosition.nx = nX;
	m_curPosition.ny = nY;

	return bRet;
}

void CGame::DrawQiZi(int nX, int nY, bool bNormal)
{
	ASSERT(nX >= 0 && nX < 8 && nY >=0 && nY < 8);

	if (bNormal) 
	{
		m_pDC->BitBlt(nX*34+8,nY*34+4,32,32,m_pQiziMask,0,0,MERGEPAINT);
		m_pDC->BitBlt(nX*34+8,nY*34+4,32,32,m_pQiziNormal,0,0,SRCAND);
	}
	else
	{
		m_pDC->BitBlt(nX*34+8,nY*34+4,32,32,m_pQiziMask,0,0,MERGEPAINT);
		m_pDC->BitBlt(nX*34+8,nY*34+4,32,32,m_pQiziDead,0,0,SRCAND);
	}
}

bool CGame::PutQiZiAndJudge(int nx, int ny)
{
	ASSERT(nx >= 0 && nx < 8 && ny >=0 && ny < 8);

	bool bRet = true;

	if (m_map[nx][ny] == kTypeNormal)
		return true;
	else if (m_map[nx][ny] == kTypeDead)
		return false;
	
	m_map[nx][ny] = kTypeNormal;

	for (int i = 0; i < 8; i++)
	{
		if (i == ny)
			continue;

		if (m_map[nx][i] == kTypeNormal)
		{
			m_map[nx][i] = kTypeDead;
			bRet = false;
		}
	}

	for (int i = 0; i < 8; i++)
	{
		if (i == nx)
			continue;

		if (m_map[i][ny] == kTypeNormal)
		{
			m_map[i][ny] = kTypeDead;
			bRet = false;
		}
	}

	for (int i = 0 , j = nx - ny; i < 8; i++, j++)
	{
		if (j < 0 || j > 7 || i == ny)
			continue;

		if (m_map[j][i] == kTypeNormal)
		{
			m_map[j][i] = kTypeDead;
			bRet = false;
		}
	}

	for (int i = 0, j = nx + ny; i < 8; i++, j--)
	{
		if (j < 0 || j > 7 || i == ny)
			continue;

		if (m_map[j][i] == kTypeNormal)
		{
			m_map[j][i] = kTypeDead;
			bRet = false;
		}
	}

	if (!bRet)
		m_map[nx][ny] = kTypeDead;

	m_bNormal = bRet;

	return bRet;
}

bool CGame::IsValid(void)
{
	return m_bNormal;
}

void CGame::SetValid(bool isValid)
{
	m_bNormal = isValid;
}

bool CGame::IsWin(void)
{
	int count = 0;
	if (!IsValid())
		return false;

	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)
			if (m_map[i][j] == kTypeNormal)
				++count;

	return count == 8;
}

void CGame::ReturnLast(void)
{
	m_map[m_curPosition.nx][m_curPosition.ny] = kTypeNone;

	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)
		{
			if (m_map[i][j] == kTypeDead)
			{
				m_map[i][j] = kTypeNormal;
			}
		}
}