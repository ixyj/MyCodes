#pragma once

#include "MyCDC.h"

struct Position
{
	int nx;
	int ny;
};

enum QiziState
{
	kTypeNone = 0,
	kTypeNormal,
	kTypeDead
};

class CGame
{
public:
	CGame(void);
	CGame(CDC* pDC, CMyCDC* m_pQP, CMyCDC* pQiziNormal, CMyCDC* pQiziDead, CMyCDC* pQiziMask);
	virtual ~CGame(void);

	virtual void Draw(void);
	virtual void InitGame(void);
	virtual void ReturnLast(void);
	virtual void SetDC(CDC* pDC, CMyCDC* m_pQP, CMyCDC* pQiziNormal, CMyCDC* pQiziDead, CMyCDC* pQiziMask);

	virtual bool PutQiZiAndJudge(int nx, int ny);
	virtual bool IsValid(void);
	virtual bool IsWin(void);
	virtual void SetValid(bool isValid = true);

private:
	CDC* m_pDC;
	CMyCDC* m_pQP;
	CMyCDC* m_pQiziNormal;
	CMyCDC* m_pQiziDead;
	CMyCDC* m_pQiziMask;

	QiziState m_map[8][8];
	bool m_bNormal;

	Position m_curPosition; 

public:
	virtual bool DownQiZi(int nX, int nY);
	virtual void DrawQiZi(int nX, int nY, bool bNormal = true);
};
