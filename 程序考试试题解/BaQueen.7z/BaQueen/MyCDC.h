#pragma once
#include "afxwin.h"

class CMyCDC :
	public CDC
{
public:
	CMyCDC(void);
	CMyCDC(LONG cx, LONG cy);
	CMyCDC(CSize size);

	virtual ~CMyCDC(void);

	virtual CSize GetSize();
	virtual void SetSize(CSize size);

private:
	CSize m_size;
};
