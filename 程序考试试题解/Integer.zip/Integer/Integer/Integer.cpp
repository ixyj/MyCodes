#include "Integer.h"

CInteger::CInteger(const char* value)
{
	ParseStringToArray(String(value), m_arrValue); 
}

CInteger::CInteger(int value)
{
	do
	{
		m_arrValue.insert(m_arrValue.begin(), value % 10);
		value /= 10;
	}while (value > 0);
}

CInteger::CInteger(const String& value)
{
	ParseStringToArray(value, m_arrValue);
}

CInteger::CInteger(const CInteger& CInt)
{
	m_arrValue.assign(CInt.m_arrValue.begin(), CInt.m_arrValue.end());
}

CInteger::CInteger(const ArrayNum& arrNum)
{
	m_arrValue.assign(arrNum.begin(), arrNum.end());
}

CInteger::~CInteger(void)
{
}

void CInteger::ParseStringToArray(const String& value, ArrayNum& arrNum) 
{
	arrNum.clear();
	if (value.empty())
	{
		arrNum.push_back(0);
		return;
	}

	for (int i = 0; i < static_cast<int>(value.size()); i++)
	{
		if (isdigit(value.at(i)))
			arrNum.push_back(value.at(i) - 0X30);
		else
			throw CException("���Ŵ���");
	}

	TrimZero(arrNum);
}

String CInteger::GetValue(void) 
{
	String retValue("");
	
	TrimZero(m_arrValue);

	for(int i = 0; i < static_cast<int>(m_arrValue.size()); i++)
	{
		retValue.append(1, static_cast<char>(m_arrValue.at(i) + 0X30));
	}

	return retValue;
}

void CInteger::TrimZero(ArrayNum& arrNum)
{
	if (arrNum.empty())
		return;

	std::vector<char>::iterator it = arrNum.begin();

	for (; it != arrNum.end(); ++it)
	{
		if (*it != 0)
			break;
	}
	arrNum.erase(arrNum.begin(), it);

	if (arrNum.empty())
	{
		arrNum.push_back(0);
	}
}

CInteger CInteger::operator = (const CInteger& CInt)
{
	m_arrValue.assign(CInt.m_arrValue.begin(), CInt.m_arrValue.end());

	return *this;
}

CInteger CInteger::operator = (const String& value)
{
	ParseStringToArray(value, m_arrValue);

	return *this;
}

CInteger CInteger::operator = (int value)
{
	m_arrValue.clear();

	do
	{
		m_arrValue.insert(m_arrValue.begin(), value % 10);
		value /= 10;
	}while (value > 0);

	return *this;
}

CInteger CInteger::operator + (const CInteger& CInt)
{
	ArrayNum arrNum;
	bool isMyself = true;

	if (m_arrValue.size() >= CInt.m_arrValue.size())
		arrNum.assign(m_arrValue.begin(), m_arrValue.end());
	else
	{
		arrNum.assign(CInt.m_arrValue.begin(), CInt.m_arrValue.end());
		isMyself = false;
	}

	char ret = 0;
	int num = arrNum.size() - 1; 

	if (isMyself)
	{
		for (int i = CInt.m_arrValue.size() - 1; i >= 0 ; i--, num--)
		{
			ret += arrNum.at(num) + CInt.m_arrValue.at(i);
			arrNum[num] = ret % 10;
			ret = ret / 10;
		}
	}
	else
	{
		for (int i = m_arrValue.size() - 1; i >= 0 ; i--, num--)
		{
			ret += arrNum.at(num) + m_arrValue.at(i);
			arrNum[num] = ret % 10;
			ret = ret / 10;
		}
	}

	for (; num >= 0 && ret == 1; num--)
	{
		ret = arrNum[num] + ret;
		arrNum[num] = ret % 10;
		ret = ret / 10;
	}
	
	if (ret == 1)
		arrNum.insert(arrNum.begin(), 1);

	TrimZero(arrNum);

	return CInteger(arrNum);
}

CInteger CInteger::operator * (const CInteger& CInt)
{
	CInteger result;
	result.m_arrValue.assign(m_arrValue.size() + CInt.m_arrValue.size(), 0);

	CInteger temp;
	int zeroNum = 0;

	for (int i = CInt.m_arrValue.size() - 1; i >= 0; i--, zeroNum++)
	{
		temp.m_arrValue.assign(m_arrValue.begin(), m_arrValue.end());
		Multiply(temp.m_arrValue, CInt.m_arrValue.at(i));

		temp.m_arrValue.insert(temp.m_arrValue.end(), zeroNum, 0);

		result = result + temp;
	}

	TrimZero(result.m_arrValue);

	return result;
}

void CInteger::Multiply(ArrayNum& arrNum, char n)
{
	if (arrNum.empty())
		return;

	char ret = 0;
	for (int i = arrNum.size() - 1; i >= 0; i--)
	{
		ret += arrNum.at(i) * n;
		arrNum[i] = ret % 10;
		ret = ret / 10;
	}

	if (ret > 0)
		arrNum.insert(arrNum.begin(), ret);
}

CInteger CInteger::Pow(int n)
{
	CInteger temp(*this);

	if (n <= 0)
		temp = 1;
	else if (n == 1)
		return temp;
	else
	{
		for (int i = 1; i < n; i++)
		{
			temp = temp * (*this);
		}
	}

	return temp;
}

bool CInteger::operator < (const CInteger& CInt)
{
	if (m_arrValue.size() < CInt.m_arrValue.size())
		return true;
	else if (m_arrValue.size() > CInt.m_arrValue.size())
		return false;

	for (int i = 0; i < static_cast<int>(m_arrValue.size()); i++)
	{
		if (m_arrValue.at(i) == m_arrValue.at(i))
			continue;
		else
			return m_arrValue.at(i) < m_arrValue.at(i);
	}

	return false;
}

bool CInteger::operator == (const CInteger& CInt)
{
	return (m_arrValue == CInt.m_arrValue);
}

std::istream& operator>>(std::istream& in, CInteger& CInt)
{
	String str;
	in >> str;
	CInt.ParseStringToArray(str, CInt.m_arrValue);

	return in;
}
std::ostream& operator<<(std::ostream& out, CInteger& CInt)
{
	out << CInt.GetValue();

	return out;
}

CInteger::operator String ()
{
	return GetValue();
}