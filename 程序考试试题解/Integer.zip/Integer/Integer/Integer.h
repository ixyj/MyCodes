#pragma once

#ifndef _INTEGER_H_
#define _INTEGER_H_

#include <string>
#include <vector>
#include <cstring>
#include <iostream>
#include <exception>

typedef std::vector<char> ArrayNum;
typedef std::string String;

class CInteger
{
public:
	CInteger(int value);
	CInteger(const char* value = "");
	CInteger(const String& value);
	CInteger(const ArrayNum& arrNum);
	CInteger(const CInteger& CInt);
	virtual ~CInteger(void);

	String GetValue(void);
	CInteger Pow(int n);

	CInteger operator = (const CInteger& CInt);
	CInteger operator = (const String& value);
	CInteger operator = (int value);
	CInteger operator + (const CInteger& CInt);
	CInteger operator * (const CInteger& CInt);

	bool operator < (const CInteger& CInt);
	bool operator == (const CInteger& CInt);

	operator String ();

	friend std::istream& operator>>(std::istream& in, CInteger& CInt);
	friend std::ostream& operator<<(std::ostream& out, CInteger& CInt);
	
private:
	void ParseStringToArray(const String& value, ArrayNum& arrNum) ;
	void TrimZero(ArrayNum& arrNum);
	void Multiply(ArrayNum& arrNum, char n); // 0 <= n <= 9

private:
	ArrayNum m_arrValue;
};


class CException : public std::exception
{
public:
	CException(const char* str = NULL):std::exception(str)
	{}
	~CException(){}

	void DealWithException()
	{
		std::cout<<"\n"<<what()<<"\n";
		std::exit(1);
	}
};

#endif
//end _INTEGER_H_