#include<iostream>

#include "Integer.h"

int main(int argc, char** argv)
{
	CInteger bigInt, temp;
	int n = 0;

	std::cout << "1^1+2^2+...+N^N,please input N:";
	std::cin >> n;

	try
	{
		
		bigInt = 0;
		for (int i =1; i <= n; i++)
		{
			temp = i;
			bigInt = bigInt + temp.Pow(i);
		}
		std::cout << "\n1^1+2^2+...+"<<n<<"^"<<n<<"="<<bigInt<<std::endl;
	}

	catch (CException e)
	{
		e.DealWithException();
	}
	return 0;
}
