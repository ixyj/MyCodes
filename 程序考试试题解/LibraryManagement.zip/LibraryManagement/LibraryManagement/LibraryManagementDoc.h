
// LibraryManagementDoc.h : CLibraryManagementDoc ��Ľӿ�
//


#pragma once
#include "LibraryManagementSet.h"


class CLibraryManagementSrvrItem;

class CLibraryManagementDoc : public COleServerDocEx
{
protected: // �������л�����
	CLibraryManagementDoc();
	DECLARE_DYNCREATE(CLibraryManagementDoc)

// ����
public:
	CLibraryManagementSrvrItem* GetEmbeddedItem()
		{ return reinterpret_cast<CLibraryManagementSrvrItem*>(COleServerDocEx::GetEmbeddedItem()); }
	CLibraryManagementSet m_LibraryManagementSet;

// ����
public:

// ��д
protected:
	virtual COleServerItem* OnGetEmbeddedItem();
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// ʵ��
public:
	virtual ~CLibraryManagementDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	DECLARE_MESSAGE_MAP()
};


