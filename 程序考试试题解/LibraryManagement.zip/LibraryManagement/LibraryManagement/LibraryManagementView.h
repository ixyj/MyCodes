
// LibraryManagementView.h : CLibraryManagementView ��Ľӿ�
//


#pragma once
#include "afxwin.h"

class CLibraryManagementSet;
class CBorrowBook;

class CLibraryManagementView : public CRecordView
{
protected: // �������л�����
	CLibraryManagementView();
	DECLARE_DYNCREATE(CLibraryManagementView)

// ʵ��
public:
	virtual ~CLibraryManagementView();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	enum{ IDD = IDD_LIBRARYMANAGEMENT_FORM };

// ����
public:
	CLibraryManagementDoc* GetDocument() const;

// ��д
protected:
	virtual CRecordset* OnGetRecordset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual void OnInitialUpdate(); // ������һ�ε���
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);


private:
	bool SetFindType(void);
	CString GetDBBookInfo(void);
	void SetControlOnlyRead(BOOL bRead = TRUE, BOOL bOperateBook = TRUE);
	void UpdateDBView(void);
	bool FromStringToTime(CTime& time, const CString string);
	void AddRecord(bool bModifyBook);
	void EditRecord(bool bModifyBook);
	void DeleteRecord(bool bModifyBook);
	void SetViewInfo(bool isNull = false);

private:
	CEdit m_bookID;
	CEdit m_bookName;
	CEdit m_bookType;
	CEdit m_bookAuthor;
	CEdit m_bookPulish;
	CEdit m_publishTime;
	CEdit m_bookCheckInTime;
	CEdit m_bookPrice;
	CComboBox m_bookInfo;
	CListBox m_allBook;
	CEdit m_borrowTime;
	CEdit m_person;
	CButton m_btnModify;

	CLibraryManagementSet* m_pSet;
	CBorrowBook* m_personSet;

	int m_modifyType;  // 0--none,1--add,2--modify,3--delete
	bool m_bModifyBook;
	int m_findType;

	
	// ���ɵ���Ϣӳ�亯��
protected:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnCancelEditSrvr();
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);

	afx_msg void OnBnClickedBtnquery();
	afx_msg void OnBnClickedRadioprice();
	afx_msg void OnBnClickedRadiopublishtime();
	afx_msg void OnLbnDblclkBook();
	afx_msg void OnBnClickedFindtype();
	afx_msg void OnBnClickedFindauthor();
	afx_msg void OnBnClickedFindpublish();
	afx_msg void OnBnClickedFindperson();
	
	afx_msg void OnBnClickedAdd();
	afx_msg void OnBnClickedModify();
	afx_msg void OnBnClickedDel();
	afx_msg void OnBnClickedSure();
	
	afx_msg void OnBnClickedmodifybook();
	afx_msg void OnBnClickedmodifyperson();
	afx_msg void OnRecordFirst();
	afx_msg void OnRecordPrev();
	afx_msg void OnRecordNext();
	afx_msg void OnRecordLast();
	afx_msg void OnBnClickedExit();
	afx_msg void OnInfo();
};


#ifndef _DEBUG  // LibraryManagementView.cpp �еĵ��԰汾
inline CLibraryManagementDoc* CLibraryManagementView::GetDocument() const
   { return reinterpret_cast<CLibraryManagementDoc*>(m_pDocument); }
#endif

