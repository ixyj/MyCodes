
// SrvrItem.h : CLibraryManagementSrvrItem ��Ľӿ�
//

#pragma once

class CLibraryManagementSrvrItem : public COleServerItem
{
	DECLARE_DYNAMIC(CLibraryManagementSrvrItem)

// ���캯��
public:
	CLibraryManagementSrvrItem(CLibraryManagementDoc* pContainerDoc);

// ����
	CLibraryManagementDoc* GetDocument() const
		{ return reinterpret_cast<CLibraryManagementDoc*>(COleServerItem::GetDocument()); }

// ��д
	public:
	virtual BOOL OnDraw(CDC* pDC, CSize& rSize);
	virtual BOOL OnGetExtent(DVASPECT dwDrawAspect, CSize& rSize);

// ʵ��
public:
	~CLibraryManagementSrvrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	virtual void Serialize(CArchive& ar);   // Ϊ�ĵ� I/O ��д
};

