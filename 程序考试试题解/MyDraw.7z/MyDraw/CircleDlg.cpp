// CircleDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MyDraw.h"
#include "CircleDlg.h"


// CCircleDlg �Ի���

IMPLEMENT_DYNAMIC(CCircleDlg, CDialog)

CCircleDlg::CCircleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCircleDlg::IDD, pParent)
	, m_x(0)
	, m_y(0)
	, m_r(0)
	,color(RGB(0,0,0))
{

}

CCircleDlg::~CCircleDlg()
{
}

void CCircleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_color, m_color);
	DDX_Text(pDX, IDC_coreX, m_x);
	DDX_Text(pDX, IDC_coreY, m_y);
	DDX_Text(pDX, IDC_radius, m_r);
}


BEGIN_MESSAGE_MAP(CCircleDlg, CDialog)
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()


// CCircleDlg ��Ϣ��������

HBRUSH CCircleDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO:  �ڴ˸��� DC ���κ�����
	HBRUSH hbrBk; 
	int idc = pWnd->GetDlgCtrlID(); 

	if(nCtlColor == CTLCOLOR_STATIC) 
	{ 
		 if(idc == IDC_color) 
		{ 
			hbrBk = ::CreateSolidBrush(color); 
			pDC->SetBkMode(TRANSPARENT); 
			pDC->SetBkColor(color); 
			return hbrBk; 
		} 
	} 
	// TODO:  ���Ĭ�ϵĲ������軭�ʣ��򷵻���һ������
	return hbr;
}
