#pragma once
#include "afxwin.h"


// CCircleDlg �Ի���

class CCircleDlg : public CDialog
{
	DECLARE_DYNAMIC(CCircleDlg)

public:
	CCircleDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CCircleDlg();

// �Ի�������
	enum { IDD = IDD_CICLE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	int m_x;
public:
	int m_y;
public:
	float m_r;
	COLORREF color;
public:
	CStatic m_color;
public:
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
};
