// Elipse.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MyDraw.h"
#include "Elipse.h"


// CElipse �Ի���

IMPLEMENT_DYNAMIC(CElipse, CDialog)

CElipse::CElipse(CWnd* pParent /*=NULL*/)
	: CDialog(CElipse::IDD, pParent)
	, m_x(0)
	, m_y(0)
	, m_l(0)
	, m_w(0)
{
	color=RGB(0,0,0);
}

CElipse::~CElipse()
{
}

void CElipse::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_color, m_color);
	DDX_Text(pDX, IDC_x, m_x);
	DDX_Text(pDX, IDC_y, m_y);
	DDX_Text(pDX, IDC_len, m_l);
	DDX_Text(pDX, IDC_width, m_w);
}


BEGIN_MESSAGE_MAP(CElipse, CDialog)
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()


// CElipse ��Ϣ��������

HBRUSH CElipse::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO:  �ڴ˸��� DC ���κ�����
HBRUSH hbrBk; 
	int idc = pWnd->GetDlgCtrlID(); 

	if(nCtlColor == CTLCOLOR_STATIC) 
	{ 
		 if(idc == IDC_color) 
		{ 
			hbrBk = ::CreateSolidBrush(color); 
			pDC->SetBkMode(TRANSPARENT); 
			pDC->SetBkColor(color); 
			return hbrBk; 
		} 
	} 
	// TODO:  ���Ĭ�ϵĲ������軭�ʣ��򷵻���һ������
	return hbr;
}
