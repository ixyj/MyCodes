#pragma once
#include "afxwin.h"


// CElipse �Ի���

class CElipse : public CDialog
{
	DECLARE_DYNAMIC(CElipse)

public:
	CElipse(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CElipse();

// �Ի�������
	enum { IDD = IDD_ELLIPDE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	int m_x;
public:
	int m_y;
public:
	int m_l;
public:
	int m_w;
	COLORREF color;
public:
	CStatic m_color;
public:
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
};
