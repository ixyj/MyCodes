#pragma once
#include "afxwin.h"


// CLinePropertyDlg �Ի���

class CLinePropertyDlg : public CDialog
{
	DECLARE_DYNAMIC(CLinePropertyDlg)

public:
	CLinePropertyDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CLinePropertyDlg();

// �Ի�������
	enum { IDD = IDD_LINE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	int m_startX;
	int m_startY;
	int m_endX;
	int m_endY;

	COLORREF color;
public:
	CStatic m_color;

protected:
	virtual void PreInitDialog();
public:
	virtual BOOL OnInitDialog();
public:
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);

};
