#include "StdAfx.h"
#include "MyData.h"

#include <string>
using namespace std;

IMPLEMENT_SERIAL(CMyData, CObject,1)
CMyData::CMyData(void)
{
	line.clear();
	circle.clear();
	elipse.clear();
	arcc.clear();
	polygonn.clear();
	fill.clear();
}

CMyData::~CMyData(void)
{
}

void CMyData::Serialize(CArchive &ar)
{
	
	if (ar.IsStoring())
	{
		ar << line.size();
		for (vector<Line>::iterator it = line.begin(); it != line.end(); ++it)
		{
			ar << (*it).color << (*it).start << (*it).end;
		}
		
		ar << circle.size();
		for (vector<Circle>::iterator it = circle.begin(); it != circle.end(); ++it)
		{
			ar << (*it).color << (*it).core << (*it).radius;
		}
		
		ar <<elipse.size();
		for (vector<Elipse>::iterator it = elipse.begin(); it != elipse.end(); ++it)
		{
			ar << (*it).color << (*it).rect;
		}

		ar << arcc.size();
		for (vector<Arcc>::iterator it = arcc.begin(); it != arcc.end(); ++it)
		{
			ar << (*it).color << (*it).rect <<(*it).start << (*it).end;
		}

		ar << polygonn.size() ;
		for (vector<Polygonn>::iterator it = polygonn.begin(); it != polygonn.end(); ++it)
		{
			ar << (*it).point.size() << (*it).color;
			for (vector<CPoint>::iterator iter = (*it).point.begin();iter != (*it).point.end();++iter)
			{
				ar<< *iter;
			}
		}

		ar << fill.size();
		for (vector<FillData>::iterator it = fill.begin(); it != fill.end(); ++it)
		{
			ar << (*it).color<<(*it).pt;
		}

	}
	else
	{
		Line l;
		line.clear();
		unsigned num = 0;

		ar >> num;
		for(unsigned i = 0; i < num; i++)
		{
			ar >> l.color >> l.start >> l.end;
			line.push_back(l);
		}
		
		circle.clear();
		Circle c;
		ar >> num;
		for(unsigned i = 0; i < num; i++)
		{
			ar >> c.color >> c.core >> c.radius;
			circle.push_back(c);
		}

		elipse.clear();
		Elipse e;
		ar >> num;
		for(unsigned i = 0; i < num; i++)
		{
			ar >> e.color >> e.rect;
			elipse.push_back(e);
		}
		
		arcc.clear();
		Arcc a;
		ar >> num;
		for(unsigned i = 0; i < num; i++)
		{
			ar >> a.color >> a.rect >> a.start >> a.end;
			elipse.push_back(e);
		}

		polygonn.clear();
		Polygonn p;
		ar >> num;
		for(unsigned i = 0; i < num; i++)
		{
			int n = 0;
			ar >> n >> p.color;
			CPoint pp;
			for (unsigned j =0; j < n;j++)
			{
				ar >> pp;
				p.point.push_back(pp);
			}
		}

		fill.clear();
		FillData f;
		ar >> num;
		for(unsigned i = 0; i < num; i++)
		{
			ar >> f.color >> f.pt;
			fill.push_back(f);
		}
	}
}