#pragma once

#include "afx.h"
#include "graph.h"

class CMyData :
	public CObject
{
	DECLARE_SERIAL(CMyData)
public:
	CMyData();
	~CMyData(void);

	virtual void Serialize(CArchive &ar);
public:
	
	std::vector<Line> line;
	std::vector<Circle> circle;
	std::vector<Elipse> elipse;
	std::vector<Arcc> arcc;
	std::vector<Polygonn> polygonn;

	std::vector<FillData> fill;

};
