// MyDrawView.cpp : CMyDrawView ���ʵ��
//

#include "stdafx.h"
#include "MyDraw.h"

#include "MyDrawDoc.h"
#include "MyDrawView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

extern CMyData data;
// CMyDrawView

IMPLEMENT_DYNCREATE(CMyDrawView, CFormView)

BEGIN_MESSAGE_MAP(CMyDrawView, CFormView)
	ON_COMMAND(ID_32771, &CMyDrawView::OnLine)
	ON_COMMAND(ID_32772, &CMyDrawView::OnCircle)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_COMMAND(ID_32773, &CMyDrawView::OnEcllipse)
	ON_COMMAND(ID_32777, &CMyDrawView::OnArc)
	ON_COMMAND(ID_32776, &CMyDrawView::OnCircleArc)
	ON_COMMAND(ID_32778, &CMyDrawView::OnColor)
	ON_WM_PAINT()
	ON_WM_SIZING()
	ON_WM_CTLCOLOR()
	ON_COMMAND(ID_32775, &CMyDrawView::OnPoly)
	ON_COMMAND(ID_32779, &CMyDrawView::OnFill)
	ON_COMMAND(ID_UNDO, &CMyDrawView::OnUndo)
	ON_COMMAND(ID_CLEAR, &CMyDrawView::OnClear)
	ON_COMMAND(ID_REDO, &CMyDrawView::OnRedo)
END_MESSAGE_MAP()

// CMyDrawView ����/����

CMyDrawView::CMyDrawView()
	: CFormView(CMyDrawView::IDD)
	,LBtnDown(false)
	,canUndo(false)
	,canRedo(false)
	,type(kNoneType)
{
	// TODO: �ڴ˴����ӹ������
	m_lineDlg.Create(IDD_LINE_DIALOG);
	m_elipseDlg.Create(IDD_ELLIPDE_DIALOG);
	m_circleDlg.Create(IDD_CICLE_DIALOG);
	m_polyDlg.Create(IDD_POLY_DIALOG);
	color = RGB(0,0,0);

	m_redo.type = kNoneType;
}

CMyDrawView::~CMyDrawView()
{
}

void CMyDrawView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BOOL CMyDrawView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: �ڴ˴�ͨ���޸�
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ

	return CFormView::PreCreateWindow(cs);
}

void CMyDrawView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}


// CMyDrawView ���

#ifdef _DEBUG
void CMyDrawView::AssertValid() const
{
	CFormView::AssertValid();
}

void CMyDrawView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CMyDrawDoc* CMyDrawView::GetDocument() const // �ǵ��԰汾��������
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMyDrawDoc)));
	return (CMyDrawDoc*)m_pDocument;
}
#endif //_DEBUG


// CMyDrawView ��Ϣ��������

void CMyDrawView::OnLine()
{
	// TODO: �ڴ�����������������
	type = kLineType;
	
	Show(type);
}

void CMyDrawView::OnCircle()
{
	// TODO: �ڴ�����������������
	type = kCircleType;
	Show(type);
	
}

void CMyDrawView::DrawGraph(CDC* pDC, CPoint point, GraphType type,bool xor)
{
	if (type == kFillType)
		return;

	if (xor)
		pDC->SetROP2(R2_NOTXORPEN);

	CPen pen;
	pen.CreatePen(PS_SOLID,1,color);
	pDC->SelectObject(&pen);

	switch(type)
	{
	case kLineType:
		pDC->MoveTo(line.back().start);
		pDC->LineTo(line.back().end);
		line.back().end = point;
		pDC->MoveTo(line.back().start);
		pDC->LineTo(line.back().end);
		
		m_lineDlg.m_endX = point.x;
		m_lineDlg.m_endY = point.y;
		m_lineDlg.UpdateData(FALSE);
		break;

	case kCircleType:
		pDC->Ellipse(circle.back().core.x - circle.back().radius,circle.back().core.y - circle.back().radius,
			circle.back().core.x + circle.back().radius,circle.back().core.y + circle.back().radius);
	
		circle.back().radius = (float)(sqrt(((float)circle.back().core.x-point.x)*(circle.back().core.x-point.x)
			+(circle.back().core.y-point.y)*(circle.back().core.y-point.y)));
		
		pDC->Ellipse(circle.back().core.x - circle.back().radius,circle.back().core.y - circle.back().radius,
			circle.back().core.x + circle.back().radius,circle.back().core.y + circle.back().radius);
	
		m_circleDlg.m_r = circle.back().radius;
		m_circleDlg.UpdateData(FALSE);
		break;

	case kElipseType:
		pDC->Ellipse(elipse.back().rect);
		elipse.back().rect.top = point.y;
		elipse.back().rect.left = point.x;
		pDC->Ellipse(elipse.back().rect);

		m_elipseDlg.m_l = abs(point.x - elipse.back().rect.right);
		m_elipseDlg.m_w = abs(point.y - elipse.back().rect.bottom);
		m_elipseDlg.UpdateData(FALSE);
		break;

	case kArccType:
		{
			POINT p1,p2;
			p1.x = arcc.back().rect.left;p1.y = arcc.back().rect.top;
			p2.x = arcc.back().rect.right;p2.y = arcc.back().rect.bottom;
			pDC->Arc(&arcc.back().rect,p1,p2);
			
			arcc.back().rect.bottom = point.y;
			arcc.back().rect.right = point.x;
			p2.x = arcc.back().rect.right;
			p2.y = arcc.back().rect.bottom;
			pDC->Arc(&arcc.back().rect,p1,p2);
		}
		break;

	case kCircleArcType:
		{
			POINT p1,p2;
			p1.x = arcc.back().rect.left;p1.y = arcc.back().rect.top;
			p2.x = arcc.back().rect.right;p2.y = arcc.back().rect.bottom;
			pDC->Arc(&arcc.back().rect,p1,p2);
			
			int len = point.x - arcc.back().rect.top;
			arcc.back().rect.bottom = arcc.back().rect.top + len;
			arcc.back().rect.right = arcc.back().rect.left + len;
			p2.x = arcc.back().rect.right;
			p2.y = arcc.back().rect.bottom;
			pDC->Arc(&arcc.back().rect,p1,p2);
		}
		break;


	default:
		ASSERT(false);
	}


}

 void CMyDrawView::SetStart(CPoint point, COLORREF color,GraphType type)
{
	if (type == kFillType)
		return;
	switch(type)
	{
	case kLineType:
		line.push_back(Line(point,point,color));
		m_lineDlg.m_startX = m_lineDlg.m_endX = point.x;
		m_lineDlg.m_startY = m_lineDlg.m_endY = point.y;
		m_lineDlg.color = color;
		m_lineDlg.Invalidate();
		break;

	case kCircleType:
		circle.push_back(Circle(point,point,color));

		m_circleDlg.m_x = point.x;
		m_circleDlg.m_y = point.y;
		m_circleDlg.m_r = 0.0f;
		m_circleDlg.color= color;
		m_circleDlg.Invalidate();
		break;

	case kElipseType:
		elipse.push_back(Elipse(point,point,color));

		m_elipseDlg.m_x = point.x;
		m_elipseDlg.m_y = point.y;
		m_elipseDlg.m_l = m_elipseDlg.m_w = 0;
		m_elipseDlg.color = color;
		m_elipseDlg.Invalidate();
		break;

	case kArccType:
		{
			CRect rect;
			rect.top = point.y;
			rect.bottom =  point.y;
			rect.left = point.x;
			rect.right = point.x;
			arcc.push_back(Arcc(rect,point,point,color));
		}
		break;

	case kCircleArcType:
		{
			CRect rect;
			rect.top = point.y;
			rect.bottom =  point.y;
			rect.left = point.x;
			rect.right = point.x;
			arcc.push_back(Arcc(rect,point,point,color));
		}
		break;

	case kPolygonnType:
		{
			m_polyDlg.UpdateData();
			std::vector<CPoint> v;
			v.push_back(point);
			v.push_back(point);
			Polygonn poly(v,color);
			polygonn.push_back(poly);
			m_polyDlg.color = color;
			m_polyDlg.Invalidate();
		}
		break;
	

	default:
		ASSERT(false);
	}
}

 void CMyDrawView::OnLButtonDown(UINT nFlags, CPoint point)
 {
	 // TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	  if (type == kFillType)
	 {
		CDC* pDC = GetDC();
		RePaintDC(pDC);
		
		CBrush brush;
		brush.CreateSolidBrush(color);
		pDC->SelectObject(&brush);

		COLORREF cr = GetPixel(pDC->GetSafeHdc(), point.x, point.y);
		for (int i = point.x-1; i>=0; i--)
		{
			COLORREF temp = GetPixel(pDC->GetSafeHdc(), i, point.y);
			if (cr != temp)
			{
				cr = temp;
				break;
			}
		}

		
		pDC->FloodFill(point.x, point.y,cr);
		FillData fd;
		fd.color = color;
		fd.pt = point;
		fill.push_back(fd);
		ReleaseDC(pDC);
		return;
	 }
	LBtnDown = true;
	static bool continuePolygonn = false;
	
	 GetClientRect(&windowScreen);						//�趨��������ķ�Χ
        ClientToScreen(&windowScreen); 
	 ClipCursor(&windowScreen);      
	 if ((type != kNoneType && type != kPolygonnType)
		 || (type == kPolygonnType && (polygonn.size() == 0 || polygonn.back().point.size() == 0)))
	 {
		SetStart(point,color,type);
	 }
	 else if (type == kPolygonnType)
	 {
		 if (polygonn.back().point.size() < m_polyDlg.m_n)
		   {
			   polygonn.back().point.push_back(point);
		   }
		 else if(!continuePolygonn)
		 {
			 CDC* pDC = GetDC();
			 CPen pen;
			pen.CreatePen(PS_SOLID,1,color);
			pDC->SelectObject(&pen);
			 pDC->MoveTo(polygonn.back().point.back());
			 pDC->LineTo(polygonn.back().point.front());
			polygonn.back().point.push_back(point);
			continuePolygonn = true;
		 }
		 else
		 {
			 continuePolygonn = false;
			SetStart(point,color,type);
		 }
	 }
	

	 CFormView::OnLButtonDown(nFlags, point);
 }

 void CMyDrawView::OnLButtonUp(UINT nFlags, CPoint point)
 {
	 // TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	 LBtnDown = false;
	 ClipCursor(NULL);   
	
	 if (type == kPolygonnType && (polygonn.size() > 0 && polygonn.back().point.size() <= m_polyDlg.m_n))
					LBtnDown = true;

	 CFormView::OnLButtonUp(nFlags, point);
 }

 void CMyDrawView::OnMouseMove(UINT nFlags, CPoint point)
 {
	 // TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	 if (type == kPolygonnType && LBtnDown)
	 {
		  CDC* pDC = GetDC();
			DrawPoly(pDC,point);
			this->ReleaseDC(pDC);
	 }
	 else if (LBtnDown && type != kNoneType)
	 {
		 CDC* pDC = GetDC();
		 DrawGraph(pDC, point, type);
		this->ReleaseDC(pDC);

	 }

	 CFormView::OnMouseMove(nFlags, point);
 }

 void CMyDrawView::OnEcllipse()
 {
	 // TODO: �ڴ�����������������
		type = kElipseType;
		Show(type);
 }

 void CMyDrawView::OnArc()
 {
	 // TODO: �ڴ�����������������
	type = kArccType;
	Show(type);
	
 }

 void CMyDrawView::OnCircleArc()
 {
	 // TODO: �ڴ�����������������
	 type = kCircleArcType;
	 Show(type);
 }

 void CMyDrawView::OnColor()
 {
	 // TODO: �ڴ�����������������

	CColorDialog colorDlg;
	colorDlg.m_cc.Flags   |= CC_FULLOPEN | CC_RGBINIT;//����ǿ��Դ򿪵�.   
	colorDlg.m_cc.rgbResult= color ;//���ѡ�����㶨���һ����ɫ
	if (colorDlg.DoModal() == IDOK)
	{
		color = colorDlg.GetColor();
	}
 }

 void CMyDrawView::Show(GraphType type)
 {
	 m_lineDlg.ShowWindow(SW_HIDE);
	m_circleDlg.ShowWindow(SW_HIDE);
	m_elipseDlg.ShowWindow(SW_HIDE);
	m_polyDlg.ShowWindow(SW_HIDE);

	switch(type)
	{
		case kLineType:
			m_lineDlg.ShowWindow(SW_NORMAL);
			break;

		case kCircleType:
			m_circleDlg.ShowWindow(SW_NORMAL);
			break;

		case kElipseType:
			m_elipseDlg.ShowWindow(SW_NORMAL);
			break;

		case kArccType:
			break;

		case kPolygonnType:
			m_polyDlg.ShowWindow(SW_NORMAL);
			break;

		case kCircleArcType:
			break;

		default:
			break;
	}
 }

 void CMyDrawView::OnPaint()
 {
	 CPaintDC dc(this); // device context for painting
	 // TODO: �ڴ˴�������Ϣ�����������
	OnDraw(&dc);

	 CFormView::OnPaint();
 }

 void CMyDrawView::RePaintDC(CDC* pDC)
 {	

	pDC->SetROP2(R2_MASKPEN);

	 for(std::vector<Line>::iterator it= line.begin();it!=line.end();++it)
	 {
		CPen pen;
		pen.CreatePen(PS_SOLID,1,(*it).color);
		pDC->SelectObject(&pen);
		 pDC->MoveTo((*it).start);
		 pDC->LineTo((*it).end);
	 }
	  for(std::vector<Circle>::iterator it= circle.begin();it!=circle.end();++it)
	 {
		CPen pen;
		pen.CreatePen(PS_SOLID,1,(*it).color);
		pDC->SelectObject(&pen);
		pDC->Ellipse((*it).core.x-(*it).radius,(*it).core.y-(*it).radius,
			(*it).core.x+(*it).radius,(*it).core.y+(*it).radius);
	 }

	  for(std::vector<Arcc>::iterator it = arcc.begin(); it != arcc.end(); ++it)
	  {
		CPen pen;
		pen.CreatePen(PS_SOLID,1,(*it).color);
		pDC->SelectObject(&pen);
		pDC->Arc(&(*it).rect,(*it).start,(*it).end);
	  }

	  for(std::vector<Elipse>::iterator it= elipse.begin();it!=elipse.end();++it)
	 {
		CPen pen;
		pen.CreatePen(PS_SOLID,1,(*it).color);
		pDC->SelectObject(&pen);
		pDC->Ellipse(&(*it).rect);
	 }

	   for(std::vector<Polygonn>::iterator it= polygonn.begin();it!=polygonn.end();++it)
	 {
		CPen pen;
		pen.CreatePen(PS_SOLID,1,(*it).color);
		pDC->SelectObject(&pen);
		pDC->MoveTo((*it).point.front());
		for(std::vector<CPoint>::iterator iter = (*it).point.begin() + 1;iter != (*it).point.end();++iter)
		{
			pDC->LineTo(*iter);
		}
		pDC->LineTo((*it).point.front());
	 }

	   for (std::vector<FillData>::iterator it = fill.begin(); it!= fill.end(); ++it)
	   {
		   CBrush brush;
		   brush.CreateSolidBrush((*it).color);
		   pDC->SelectObject(&brush);
		   pDC->FloodFill((*it).pt.x,(*it).pt.y,(*it).color);
	   }
 }

 void CMyDrawView::OnDraw(CDC* pDC)
 {
	 // TODO: �ڴ�����ר�ô����/����û���
	 RePaintDC(pDC);
 }

 BOOL CMyDrawView::PreTranslateMessage(MSG* pMsg)
 {
	 // TODO: �ڴ�����ר�ô����/����û���
	 
	
	 return CFormView::PreTranslateMessage(pMsg);
 }

 void CMyDrawView::OnSizing(UINT fwSide, LPRECT pRect)
 {
	 CFormView::OnSizing(fwSide, pRect);

	 // TODO: �ڴ˴�������Ϣ�����������
 }

 HBRUSH CMyDrawView::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
 {
	 HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);

	 // TODO:  �ڴ˸��� DC ���κ�����

	 // TODO:  ���Ĭ�ϵĲ������軭�ʣ��򷵻���һ������
	 return hbr;
 }

 void CMyDrawView::OnPoly()
 {
	 // TODO: �ڴ�����������������
	 type = kPolygonnType;
	 Show(type);
 }

 void CMyDrawView::DrawPoly(CDC* pDC, CPoint point, bool xor)
 {
	 if (xor)
		pDC->SetROP2(R2_NOTXORPEN);

	CPen pen;
	pen.CreatePen(PS_SOLID,1,color);
	pDC->SelectObject(&pen);

	size_t size = polygonn.back().point.size();
	if (size <= m_polyDlg.m_n)
	{
		pDC->MoveTo(polygonn.back().point.at(size-2));
		pDC->LineTo(polygonn.back().point.at(size-1));

		polygonn.back().point.at(size-1) = point;
		pDC->MoveTo(polygonn.back().point.at(size-2));
		pDC->LineTo(polygonn.back().point.at(size-1));
	}

	m_polyDlg.m_p.Format(L"(%d,%d)",point.x, point.y);
	m_polyDlg.UpdateData(FALSE);
 }

 void CMyDrawView::OnFill()
 {
	 // TODO: �ڴ�����������������
	 type = kFillType;
	Show(kFillType);

 }

 void CMyDrawView::Undo()
 {
	 m_redo.type = type;
	 CDC* pDC = GetDC();
	 pDC->SetROP2(R2_NOTXORPEN);

	CPen pen;

	 switch(type)
	 {
		 case kLineType:
			 if (line.empty())
				 return;

			 m_redo.line = line.back();
			 line.erase(line.end()-1);

			 pen.CreatePen(PS_SOLID,1,m_redo.line.color);
			 pDC->SelectObject(&pen);
			 pDC->MoveTo(m_redo.line.start);
			 pDC->LineTo(m_redo.line.end);
			 break;

		 case kCircleType:
			 if (circle.empty())
				 return;

			 m_redo.circle = circle.back();
			 circle.erase(circle.end()-1);	
			 
			 pen.CreatePen(PS_SOLID,1,m_redo.circle.color);
			 pDC->SelectObject(&pen);

			 pDC->Ellipse(m_redo.circle.core.x-m_redo.circle.radius,m_redo.circle.core.y-m_redo.circle.radius,
				 m_redo.circle.core.x + m_redo.circle.radius,m_redo.circle.core.y+m_redo.circle.radius);
			 break;

		 case kElipseType:
			 if (elipse.empty())
				 return;

			 m_redo.elipse = elipse.back();
			 elipse.erase(elipse.end()-1);
			
			 pen.CreatePen(PS_SOLID,1,m_redo.elipse.color);
			 pDC->SelectObject(&pen);

			 pDC->Ellipse(&m_redo.elipse.rect);
			 break;

		case kArccType:
		case kCircleArcType:
			if (arcc.empty())
				return;

			 m_redo.arcc = arcc.back();
			 arcc.erase(arcc.end()-1);

			pen.CreatePen(PS_SOLID,1,m_redo.arcc.color);
			pDC->SelectObject(&pen);

			pDC->Arc(&m_redo.arcc.rect,m_redo.arcc.start,  m_redo.arcc.end);
			 break;
			 break;

		case kPolygonnType:
			{
				if (polygonn.empty())
					return;

				 m_redo.polygonn = polygonn.back();
				 polygonn.erase(polygonn.end()-1);
				pen.CreatePen(PS_SOLID,1,m_redo.polygonn.color);
				pDC->SelectObject(&pen);
				
				CPoint* ppt = new CPoint[m_redo.polygonn.point.size()];
				for (int i = 0 ; i< m_redo.polygonn.point.size();i++)
					*(ppt+i) = m_redo.polygonn.point.at(i);

				pDC->Polygon(ppt,m_redo.polygonn.point.size());

				delete[] ppt;
				ppt = NULL;

			}
			 break;

		case kFillType:
			{
				if (fill.empty())
					return;

				m_redo.fill = fill.back();
				fill.erase(fill.end()-1);

				CBrush brush;
				brush.CreateSolidBrush( ~m_redo.fill.color);
				pDC->SelectObject(&brush);

				COLORREF cr = GetPixel(pDC->GetSafeHdc(), m_redo.fill.pt.x, m_redo.fill.pt.y);
				for (int i = m_redo.fill.pt.x-1; i>=0; i--)
				{
					COLORREF temp = GetPixel(pDC->GetSafeHdc(), i, m_redo.fill.pt.y);
					if (cr != temp)
					{
						cr = temp;
						break;
					}
				}

				pDC->FloodFill(m_redo.fill.pt.x, m_redo.fill.pt.y, cr);
			}
			break;

		case kNoneType:
			break;

		default:
			ASSERT(false);
	 }
 }

  void CMyDrawView::Redo()
 {
	 m_redo.type = type;
	 CDC* pDC = GetDC();
	 pDC->SetROP2(R2_MASKPEN);
	 CPen pen;
	
	 switch(m_redo.type)
	 {
		 case kLineType:

			 line.push_back(m_redo.line);
			 pen.CreatePen(PS_SOLID,1,m_redo.line.color);
			 pDC->SelectObject(&pen);

			 pDC->MoveTo(m_redo.line.start);
			 pDC->LineTo(m_redo.line.end);
			 break;

		 case kCircleType:
		
			 circle.push_back(m_redo.circle);
			 pen.CreatePen(PS_SOLID,1,m_redo.circle.color);
			 pDC->SelectObject(&pen);

			 pDC->Ellipse(m_redo.circle.core.x-m_redo.circle.radius,m_redo.circle.core.y-m_redo.circle.radius,
				 m_redo.circle.core.x + m_redo.circle.radius,m_redo.circle.core.y+m_redo.circle.radius);
			 break;

		 case kElipseType:
			 
			 elipse.push_back(m_redo.elipse);
			 pen.CreatePen(PS_SOLID,1,m_redo.elipse.color);
			 pDC->SelectObject(&pen);

			 pDC->Ellipse(&m_redo.elipse.rect);
			 break;

		case kArccType:
		case kCircleArcType:
			
			arcc.push_back(m_redo.arcc);
			pen.CreatePen(PS_SOLID,1,m_redo.arcc.color);
			pDC->SelectObject(&pen);

			pDC->Arc(&m_redo.arcc.rect, m_redo.arcc.start, m_redo.arcc.end);
			 break;

		case kPolygonnType:
			{
				polygonn.push_back(m_redo.polygonn);
				pen.CreatePen(PS_SOLID,1,m_redo.polygonn.color);
				pDC->SelectObject(&pen);
				
				CPoint* ppt = new CPoint[m_redo.polygonn.point.size()];
				for (int i = 0 ; i< m_redo.polygonn.point.size();i++)
					*(ppt+i) = m_redo.polygonn.point.at(i);

				pDC->Polygon(ppt,m_redo.polygonn.point.size());

				delete[] ppt;
				ppt = NULL;
			}
			 break;

		case kFillType:
			{
				fill.push_back(m_redo.fill);
				
				CBrush brush;
				brush.CreateSolidBrush( m_redo.fill.color);
				pDC->SelectObject(&brush);

				COLORREF cr = GetPixel(pDC->GetSafeHdc(), m_redo.fill.pt.x, m_redo.fill.pt.y);
				for (int i = m_redo.fill.pt.x-1; i>=0; i--)
				{
					COLORREF temp = GetPixel(pDC->GetSafeHdc(), i, m_redo.fill.pt.y);
					if (cr != temp)
					{
						cr = temp;
						break;
					}
				}

				pDC->FloodFill(m_redo.fill.pt.x, m_redo.fill.pt.y, m_redo.fill.color);
			}
			break;

		case kNoneType:
			break;

		default:
			ASSERT(false);
	 }

	 ReleaseDC(pDC);
 }

 void CMyDrawView::OnUndo()
 {
	 // TODO: �ڴ�����������������
	 Undo();
	 RePaintDC(GetDC());
 }

 void CMyDrawView::OnClear()
 {
	 // TODO: �ڴ�����������������
	 line.clear();
	 circle.clear();
	 elipse.clear();
	 arcc.clear();
	 polygonn.clear();
 }

 void CMyDrawView::OnRedo()
 {
	 // TODO: �ڴ�����������������
	Redo();
 }
