// MyDrawView.h : CMyDrawView ��Ľӿ�
//
#include "graph.h"
#include "LinePropertyDlg.h"
#include "Elipse.h"
#include "CircleDlg.h"
#include "PolyDlg.h"

#pragma once



struct uRedo
{
	Line line;
	Circle circle;
	Elipse elipse;
	Arcc arcc;
	Polygonn polygonn;
	FillData fill;
	int type;
};

class CMyDrawView : public CFormView
{
protected: // �������л�����
	CMyDrawView();
	DECLARE_DYNCREATE(CMyDrawView)

public:
	enum{ IDD = IDD_MYDRAW_FORM };

// ����
public:
	CMyDrawDoc* GetDocument() const;

// ����
public:

// ��д
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual void OnInitialUpdate(); // ������һ�ε���

// ʵ��
public:
	virtual ~CMyDrawView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

public:
	bool canUndo;
	bool canRedo;
	bool LBtnDown;
	GraphType type;
	COLORREF color;
	CRect windowScreen;

	std::vector<Line> line;
	std::vector<Circle> circle;
	std::vector<Elipse> elipse;
	std::vector<Arcc> arcc;
	std::vector<Polygonn> polygonn;

	std::vector<FillData> fill;

	uRedo m_redo;
	////////////////////
	CLinePropertyDlg m_lineDlg;
	CElipse m_elipseDlg;
	CCircleDlg m_circleDlg;
	CPolyDlg m_polyDlg;
	
// ���ɵ���Ϣӳ�亯��
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLine();
public:
	afx_msg void OnCircle();
public:
	virtual void DrawGraph(CDC* pDC, CPoint point, GraphType type, bool xor = true);
	virtual void SetStart(CPoint point, COLORREF color,GraphType type);
	virtual void Show(GraphType type);
	virtual void RePaintDC(CDC*);

	virtual void Undo();
	virtual void Redo();
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
public:
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
public:
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
public:
	afx_msg void OnEcllipse();
public:
	afx_msg void OnArc();
public:
	afx_msg void OnCircleArc();
public:
	afx_msg void OnColor();
public:
	afx_msg void OnPaint();
protected:
	virtual void OnDraw(CDC* /*pDC*/);
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
public:
	afx_msg void OnSizing(UINT fwSide, LPRECT pRect);
public:
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
public:
	afx_msg void OnPoly();
public:
	virtual void DrawPoly(CDC* pDC, CPoint point, bool xor = true);
public:
	afx_msg void OnFill();

	afx_msg void OnUndo();
	afx_msg void OnClear();
	afx_msg void OnRedo();
};

#ifndef _DEBUG  // MyDrawView.cpp �еĵ��԰汾
inline CMyDrawDoc* CMyDrawView::GetDocument() const
   { return reinterpret_cast<CMyDrawDoc*>(m_pDocument); }
#endif

