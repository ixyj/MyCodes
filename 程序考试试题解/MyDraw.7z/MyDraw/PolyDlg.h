#pragma once
#include "afxwin.h"
#include <vector>

// CPolyDlg �Ի���

class CPolyDlg : public CDialog
{
	DECLARE_DYNAMIC(CPolyDlg)

public:
	CPolyDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPolyDlg();

// �Ի�������
	enum { IDD = IDD_POLY_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	COLORREF color;
public:
	int m_n;
public:
	CString m_p;
public:
	int x;
public:
	int y;
public:
	CStatic m_color;
public:
	virtual BOOL OnInitDialog();
public:
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
};
