#ifndef _MY_GRAPH_H_
#define _MY_GRAPH_H_

struct Line
{
	Line()
	{
		start = CPoint(0,0);
		end = CPoint(0,0);
		color = RGB(0,0,0);
	}

	Line(CPoint start,CPoint end,COLORREF color = RGB(0,0,0))
	{
		this->start = start;
		this->end = end;
		this->color = color;

	}

	
	CPoint start;
	CPoint end;
	COLORREF color;
};

struct Circle
{
	Circle()
	{
		core = CPoint(0,0);
		radius = 0.0f;
		color = RGB(0,0,0);
	}

	Circle(CPoint core,CPoint point,COLORREF color = RGB(0,0,0))
	{
		this->core = core;
		radius = static_cast<float>(sqrt(((float)core.x-point.x)*(core.x-point.x)+(core.y-point.y)*(core.y-point.y)));
		this->color = color;

	}

	CPoint core;
	float radius;
	COLORREF color;
};


struct Elipse
{
	Elipse()
	{
		rect = CRect(0,0,0,0);
		color = RGB(0,0,0);
	}

	Elipse(CPoint start,CPoint end,COLORREF color = RGB(0,0,0))
	{
		rect = CRect(start,end);
		this->color = color;

	}

	CRect rect;
	COLORREF color;
};

struct Arcc
{
	Arcc()
	{
		rect = CRect(0,0,0,0);
		start = CPoint(0,0);
		end = CPoint(0,0);
		color = RGB(0,0,0);
	}

	Arcc(CRect rect,CPoint start,CPoint end,COLORREF color = RGB(0,0,0))
	{
		this->rect = rect;
		this->start = start;
		this->end = end;
		this->color = color;

	}

	CRect rect;
	CPoint start;
	CPoint end;
	COLORREF color;
};


struct Polygonn
{
	Polygonn(int num = 3)
	{
		for (int i=0;i<num;i++)
			point.push_back(CPoint(0,0));
		color = RGB(0,0,0);
	}

	Polygonn(const std::vector<CPoint> arrPoint,COLORREF color = RGB(0,0,0))
	{
		point = arrPoint;
		this->color = color;
	}

	~Polygonn()
	{
	}

	std::vector<CPoint> point;
	COLORREF color;
};

struct FillData
{
	CPoint pt;
	COLORREF color;
};

enum GraphType
{
	kNoneType = 0,
	kLineType,
	kCircleType,
	kElipseType,
	kArccType,
	kPolygonnType,
	kCircleArcType,
	kFillType
};

#endif
