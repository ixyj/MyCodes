//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MyDraw.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_MYDRAW_FORM                 101
#define IDR_MAINFRAME                   128
#define IDR_MyDrawTYPE                  129
#define IDD_DIALOG1                     130
#define IDD_LINE_DIALOG                 130
#define IDD_CICLE_DIALOG                131
#define IDD_ELLIPDE_DIALOG              132
#define IDD_POLO_DIALOG                 133
#define IDD_POLY_DIALOG                 133
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT3                       1002
#define IDC_EDIT4                       1003
#define IDC_COMBOBOXEX1                 1006
#define IDC_LINE_COLOR                  1007
#define IDC_coreX                       1008
#define IDC_coreY                       1009
#define IDC_radius                      1010
#define IDC_color                       1011
#define IDC_x                           1012
#define IDC_y                           1013
#define IDC_len                         1014
#define IDC_width                       1015
#define IDC_num                         1016
#define IDC_point                       1017
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_32774                        32774
#define ID_32775                        32775
#define ID_32776                        32776
#define ID_32777                        32777
#define ID_32778                        32778
#define ID_32779                        32779
#define ID                              32780
#define ID_UNDO                         32781
#define ID_32782                        32782
#define ID_CLEAR                        32783
#define ID_32784                        32784
#define ID_REDO                         32785

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32786
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
