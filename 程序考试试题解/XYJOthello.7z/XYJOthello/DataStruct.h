#ifndef _XYJ_DATA_STRUCT_
#define _XYJ_DATA_STRUCT_

#pragma once

#include <cassert>
#include <vector>
#include <algorithm>


namespace xtl
{

	const INT8 CHESS_BLACK = -1;
	const INT8 CHESS_WHITE = 1;
	const INT8 CHESS_NONE = 0;
	const INT8 CHESS_TO = -2;

	const int GAME_LEVEL_PRIMARY = 6;
	const int GAME_LEVEL_INTERMEDIATE = 6;

	struct Position
	{
		Position(INT8 PosX = 0, INT8 PosY = 0):x(PosX), y(PosY)
		{
			assert(x >= 0 && x < 8 && y >= 0 && y < 8);
		}

		void SetPos(INT8 PosX, INT8 PosY)
		{
			assert(x >= 0 && x < 8 && y >= 0 && y < 8);

			x = PosX;
			y = PosY;
		}

		bool operator==(const Position& pos)
		{
			return (x == pos.x && y == pos.y);
		}

		Position& operator=(const Position& pos)
		{
			x = pos.x;
			y = pos.y;

			assert(x >= 0 && x < 8 && y >= 0 && y < 8);
			return *this;
		}

		INT8 x:4;
		INT8 y:4;
	};
	typedef std::vector<Position> ArrayPos;

	template <class T, int N>
	void InitArray(T (&Array)[N], T value = 0)
	{
		for (int i = 0; i < N; i++)
			*(Array + i) = value;
	}

	template <class T, int N1, int N2>
	void InitArray(T (&Array)[N1][N2],  T value = 0)
	{
		for (int i = 0; i < N1; i++)
			InitArray<INT8, N2>(*(Array+i), 0);
	}

	template <class T, int N1, int N2>
	void SetArray(T (&Array)[N1][N2],  const T (&Array1)[N1][N2])
	{
		for (int i = 0; i < N1; i++)
			for (int j = 0; j < N2; j++)
				*(*(Array + i) + j) = *(*(Array1 + i) + j);
	}

	
}

#endif
//endif _XYJ_DATA_STRUCT_