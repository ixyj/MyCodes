#include "StdAfx.h"
#include "MyCDC.h"

CMyCDC::CMyCDC(void)
{
	m_size.cx = 0;
	m_size.cy = 0;
}

CMyCDC::CMyCDC(LONG cx, LONG cy)
{
	m_size.cx = cx;
	m_size.cy = cy;
}

CMyCDC::CMyCDC(CSize size)
{
	m_size = size;
}

CMyCDC::~CMyCDC(void)
{
}

CSize CMyCDC::GetSize()
{
	return m_size;
}

void CMyCDC::SetSize(CSize size)
{
	m_size.SetSize(size.cx, size.cy);
}