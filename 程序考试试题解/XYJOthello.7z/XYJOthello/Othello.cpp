#include "StdAfx.h"
#include "Othello.h"
#include "resource.h"


COthello::COthello(void)
: m_doing(true)
, m_isAI(true)
, m_level(xtl::GAME_LEVEL_PRIMARY)
, m_side(xtl::CHESS_BLACK)
{
}

COthello::~COthello(void)
{
}

void COthello::SetDC(CDC* pDC)
{
	m_pDC = pDC;
}

void COthello::LoadImage(void)
{
	CBitmap bitmap;
	CSize size;

	bitmap.LoadBitmap(IDB_CHESS);
	size.cx = 560;
	size.cy = 560;
	m_chess.CreateCompatibleDC(NULL);
	m_chess.SelectObject(&bitmap);
	m_chess.SetSize(size);
	bitmap.DeleteObject();

	bitmap.LoadBitmap(IDB_WHITE);
	size.cx = 27;
	size.cy = 27;
	m_qiziWhite.CreateCompatibleDC(NULL);
	m_qiziWhite.SelectObject(&bitmap);
	m_qiziWhite.SetSize(size);
	bitmap.DeleteObject(); 

	bitmap.LoadBitmap(IDB_BLACK);
	size.cx = 27;
	size.cy = 27;
	m_qiziBlack.CreateCompatibleDC(NULL);
	m_qiziBlack.SelectObject(&bitmap);
	m_qiziBlack.SetSize(size);
	bitmap.DeleteObject(); 

	bitmap.LoadBitmap(IDB_MASK);
	size.cx = 27;
	size.cy = 27;
	m_qiziMask.CreateCompatibleDC(NULL);
	m_qiziMask.SelectObject(&bitmap);
	m_qiziMask.SetSize(size);
	bitmap.DeleteObject();

	bitmap.LoadBitmap(IDB_CANPLACE);
	size.cx = 27;
	size.cy = 27;
	m_qiziTo.CreateCompatibleDC(NULL);
	m_qiziTo.SelectObject(&bitmap);
	m_qiziTo.SetSize(size);
	bitmap.DeleteObject();
}


void COthello::Draw(void)
{
	ASSERT(m_pDC != NULL);

	CSize size = m_chess.GetSize();
	m_pDC->BitBlt(0, 0,size.cx,size.cy, &m_chess, 0, 0, SRCCOPY);//������

	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)
		{
			DrawPane(m_map, j, i, m_map[i][j]);
		}
}

void COthello::DrawPane(INT8 (&map)[8][8], int x, int y, INT8 side)
{
	ASSERT(m_pDC != NULL);
	ASSERT(x < 8 && x >= 0 && y < 8 && y >= 0);

	if (side == xtl::CHESS_BLACK)
	{
		m_pDC->BitBlt(48*x+43,48*y+43,32,32,&m_qiziMask,0,0,MERGEPAINT);
		m_pDC->BitBlt(48*x+43,48*y+43,32,32,&m_qiziBlack,0,0,SRCAND);
	}
	else if (side == xtl::CHESS_WHITE)
	{
		m_pDC->BitBlt(48*x+43,48*y+43,32,32,&m_qiziMask,0,0,MERGEPAINT);
		m_pDC->BitBlt(48*x+43,48*y+43,32,32,&m_qiziWhite,0,0,SRCAND);
	}
	else if (side == xtl::CHESS_TO)
	{
		m_pDC->BitBlt(48*x+51,48*y+51,10,10,&m_qiziTo,0,0,MERGEPAINT);
	}
}


void COthello::InitGame()
{
	xtl::InitArray<INT8>(m_map);

	m_map[3][3] = xtl::CHESS_WHITE;
	m_map[4][4] = xtl::CHESS_WHITE;
	m_map[4][3] = xtl::CHESS_BLACK;
	m_map[3][4] = xtl::CHESS_BLACK;

	if (m_side == xtl::CHESS_WHITE && m_isAI == true)
	{
		PutFirstBlackQiZiWithAI();
		m_side = xtl::CHESS_WHITE;
	}
	
	GetNextPos(m_map, m_side);
	m_doing = true;
}


//void COthello::PutDownQiZi(INT8 (&map)[8][8], int x, int y, INT8 side, bool draw)
//{
//	ASSERT(x >= 0 && x <= 7 && y >= 0 && y <=7);
//	
//	if (draw)
//		DrawPane(map, x, y, side);
//
//}

int COthello::JudgePutDownQiZi(INT8 (&map)[8][8], int x, int y, INT8 side, xtl::ArrayPos& arrToPos)
{
	INT8 rival = -side;
	arrToPos.clear();

	ASSERT(x <= 7 && x >= 0 && y <=7 && y >= 0);
/////////////////////////////////////////////////////////////////
	int place = y + 1;
	while (place < 7 && map[place][x] == rival)
		place++;
	if (place < 8 && place > y + 1 && map[place][x] == side)
		for(int temp = y + 1; temp < place; temp++)
		{
			arrToPos.push_back(xtl::Position(x,temp));
		}

	place = y - 1;
	while (place > 0 && map[place][x] == rival)
		place--;
	if (place >= 0 && place < y-1 && map[place][x] == side)
		for(int temp = y - 1; temp > place; temp--)
		{
			arrToPos.push_back(xtl::Position(x,temp));
		}
/////////////////////////////////////////////////////////////////
	place = x + 1;
	while (place < 7 && map[y][place] == rival)
		place++;
	if (place < 8 && place > x+1 && map[y][place] == side)
		for(int temp = x + 1; temp < place; temp++)
		{
			arrToPos.push_back(xtl::Position(temp, y));
		}

	place = x - 1;
	while (place > 0 && map[y][place] == rival)
		place--;
	if (place >= 0 && place < x-1 && map[y][place] == side)
		for(int temp = x - 1; temp > place; temp--)
		{
			arrToPos.push_back(xtl::Position(temp, y));
		}
/////////////////////////////////////////////////////////////////
	int posX = x + 1, posY = y + 1;
	while (posX < 7 && posY < 7 && map[posY][posX] == rival)
	{
		posX++;
		posY++;
	}
	if (posX < 8 && posY < 8 && posX > x+1 && map[posY][posX] == side)
		for(int tempX = x + 1, tempY = y + 1; tempX < posX; tempX++,tempY++)
		{
			arrToPos.push_back(xtl::Position(tempX, tempY));
		}

	posX = x - 1, posY = y - 1;
	while (posX > 0 && posY > 0 && map[posY][posX] == rival)
	{
		posX--;
		posY--;
	}
	if (posX >= 0 && posY >= 0 && posX < x-1 && map[posY][posX] == side)
		for(int tempX = x - 1, tempY = y - 1; tempX > posX; tempX--,tempY--)
		{
			arrToPos.push_back(xtl::Position(tempX, tempY));
		}
/////////////////////////////////////////////////////////////////
	posX = x + 1, posY = y - 1;
	while (posX < 7 && posY > 0 && map[posY][posX] == rival)
	{
		posX++;
		posY--;
	}
	if (posX < 8 && posY >= 0 && posX > x+1 && map[posY][posX] == side)
		for(int tempX = x + 1, tempY = y - 1; tempX < posX; tempX++,tempY--)
		{
			arrToPos.push_back(xtl::Position(tempX, tempY));
		}

	posX = x - 1, posY = y + 1;
	while (posX > 0 && posY < 7 && map[posY][posX] == rival)
	{
		posX--;
		posY++;
	}
	if (posX >= 0 && posY < 8 && posX < x-1 && map[posY][posX] == side)
		for(int tempX = x - 1, tempY = y + 1; tempX > posX; tempX--,tempY++)
		{
			arrToPos.push_back(xtl::Position(tempX, tempY));
		}
/////////////////////////////////////////////////////////////////

		return static_cast<int>(arrToPos.size());
}


bool COthello::JudgePutDownQiZi(INT8 (&map)[8][8], int x, int y, INT8 side)
{
	INT8 rival = -side;
	
	ASSERT(x <= 7 && x >= 0 && y <=7 && y >= 0);
/////////////////////////////////////////////////////////////////
	int place = y + 1;
	while (place < 7 && map[place][x] == rival)
		place++;
	if (place < 8 && place > y + 1 && map[place][x] == side)
		return true;

	place = y - 1;
	while (place > 0 && map[place][x] == rival)
		place--;
	if (place >= 0 && place < y-1 && map[place][x] == side)
		return true;
/////////////////////////////////////////////////////////////////
	place = x + 1;
	while (place < 7 && map[y][place] == rival)
		place++;
	if (place < 8 && place > x + 1 && map[y][place] == side)
		return true;

	place = x - 1;
	while (place > 0 && map[y][place] == rival)
		place--;
	if (place >= 0 && place < x - 1 && map[y][place] == side)
		return true;
/////////////////////////////////////////////////////////////////
	int posX = x + 1, posY = y + 1;
	while (posX < 7 && posY < 7 && map[posY][posX] == rival)
	{
		posX++;
		posY++;
	}
	if (posX < 8 && posY < 8 && posX > x+1 && posY > y+1 && map[posY][posX] == side)
		return true;

	posX = x - 1, posY = y - 1;
	while (posX > 0 && posY > 0 && map[posY][posX] == rival)
	{
		posX--;
		posY--;
	}
	if (posX >= 0 && posY >= 0 && posX < x-1 && map[posY][posX] == side)
		return true;
/////////////////////////////////////////////////////////////////
	posX = x + 1, posY = y - 1;
	while (posX < 7 && posY > 0 && map[posY][posX] == rival)
	{
		posX++;
		posY--;
	}
	if (posX < 8 && posY >=0 && posX > x+1 && map[posY][posX] == side)
		return true;

	posX = x - 1, posY = y + 1;
	while (posX > 0 && posY < 7 && map[posY][posX] == rival)
	{
		posX--;
		posY++;
	}
	if (posX >= 0 && posY < 8 && posX < x-1 && map[posY][posX] == side)
		return true;
/////////////////////////////////////////////////////////////////

	return false;
}

bool COthello::PutDownQiZi(int x, int y, INT8& side, wstring& strInfo)   //����״̬�ı�ʱ����TRUE
{
	if (!IsPlaying())
	{
		strInfo = L"��Ϸδ��ʼ��";
		m_doing = false;
		return true;
	}

	bool bRet = false;

	ASSERT(x <= 7 && x >= 0 && y <=7 && y >= 0);

	if (m_map[y][x] != xtl::CHESS_TO)
	{
		strInfo = L"��λ�ò����������ӣ�";
		return false;//δ�����������Ӳ��Ϸ�
	}

	ClearNextPos(m_map);

	PutDownQiZi(x, y, side);
	side = -side;

	if (!GetNextPos(m_map, side))
	{
		strInfo = L"�������ӿ��£�������һ����";
		side = -side;
		ClearNextPos(m_map);

		if (!GetNextPos(m_map, side))
		{
			strInfo = L"��Ϸ������";
			m_doing = false;
		}
		
		return true;
	}

	bRet = true;
Draw();
	if (m_isAI)
	{
		bRet = PutDownQiZiWithAI(m_map, side, strInfo);
	}
	
	return bRet;
}

void COthello::PutDownQiZi(int x, int y ,INT8 side)
{
	m_map[y][x] = side;

	Reverse(m_map, x, y, side);
}

bool COthello::PutDownQiZiWithAI(INT8 (&map)[8][8], INT8& side, wstring& strInfo)
{
	int result = GetAlphaBeta(map, side, m_level, MaxAlpha, MinBeta);

	ClearNextPos(map);

	side = -side;

	if (!GetNextPos(map, side))
	{
		strInfo = L"�����ӿ��£�������һ����";
		side = -side;
		ClearNextPos(map);

		if (GetAlphaBeta(map, side, m_level, MaxAlpha, MinBeta) == NoStep)
		{
			strInfo = L"��Ϸ������";
			m_doing = false;
			return true;
		}
	}
 
	return true;
}

void COthello::PutFirstBlackQiZiWithAI(void)
{
	PutDownQiZi(2, 3,xtl::CHESS_BLACK);
	Draw();
}

bool COthello::GetNextPos(INT8 (&map)[8][8], INT8 side)
{
	bool bRet = false;
	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)
		{
			if(map[i][j] == xtl::CHESS_NONE && JudgePutDownQiZi(map, j, i, side))
			{
				map[i][j] = xtl::CHESS_TO;
				bRet = true;
			}
		}

	return bRet;
}

void COthello::ClearNextPos(INT8 (&map)[8][8])
{
	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)
		{
			if(map[i][j] == xtl::CHESS_TO)
			{
				map[i][j] = xtl::CHESS_NONE;
			}
		}
}

bool COthello::CanPutQiZi(INT8 (&map)[8][8], int x, int y, INT8 side)
{
	return (map[y][x] == xtl::CHESS_TO);
}

void COthello::Reverse(INT8 (&map)[8][8], int x, int y, INT8 side)
{
	xtl::ArrayPos arrPos;
	arrPos.clear();

	JudgePutDownQiZi(map, x, y, side, arrPos);


	for(xtl::ArrayPos::iterator it = arrPos.begin(); it != arrPos.end(); ++it)
	{
		map[(*it).y][(*it).x] = side;
	}
}

void COthello::GetInfo(wstring& strInfo)
{
	int nBlack = 0, nWhite = 0;
	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)
		{
			if (m_map[i][j] == xtl::CHESS_BLACK)
				nBlack++;
			else if (m_map[i][j] == xtl::CHESS_WHITE)
				nWhite++;
		}
	CString str;
	str.Format(L"���壺%d, ���壺%d",nBlack, nWhite);
	strInfo = str.GetBuffer();
}


bool COthello::HasPane()const
{
	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)
		{
			if (m_map[i][j] == xtl::CHESS_NONE)
			{
				return true;
			}
		}

	return false;
}

bool COthello::HasSpace()const
{
	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)
		{
			if (m_map[i][j] == xtl::CHESS_NONE || m_map[i][j] == xtl::CHESS_TO)
			{
				return true;
			}
		}

	return false;
}

INT8 COthello::WhoWin(void)
{
	int nBlack = 0, nWhite = 0;

	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)
		{
			if (m_map[i][j] == xtl::CHESS_BLACK)
			{
				nBlack++;
			}
			else if (m_map[i][j] == xtl::CHESS_WHITE)
			{
				nWhite++;
			}
		}

	if (nWhite >= nBlack)
		return xtl::CHESS_WHITE;
	else
		return xtl::CHESS_BLACK;
}

//INT8 COthello::WhoTurn() const
//{
//	if (m_doing)
//		return m_side;
//	else
//		return xtl::CHESS_NONE;
//}

int COthello::GetBest1(INT8 (&map)[8][8], INT8 side)
{
	int num = 0;
	for (int i = 0; i < 8; i++)
		for (int j = 0; j<8 && map[i][j]==side; j++)
			num++;

	return num;
}

int COthello::GetBest2(INT8 (&map)[8][8], INT8 side)
{
	int num = 0;
	int x= 0, y = 0;
	INT8 rival = -side;

	int start=0, end=0;
	for (y=0; y<8; y++)
	{
		if (map[y][0]==side)
			num+=4;
		if (map[y][7]==side)
			num+=4;

		x=0;
		start=-1;
		end=7;
		while (x<8)
		{
			for (;x<8&&map[y][x]!=side;x++) start=x;//not side
			for (;x<8&&map[y][x]==side;x++) end=x;//side
			if (start >=8)
				break;

			if (!(start!=-1 && end!=7 && ((map[y][start]==rival && map[y][x]!=rival)||(map[y][start]!=rival && map[y][x]==rival))))
				num += x-start;
		}
	}

	for (x = 0; x < 8; x++)
	{
		if(map[0][x]==side)
			num += 4;
		if(map[7][x]==side)
			num += 4;

		y=0;
		start=-1;
		end=7;
		while (y<8)
		{
			for (;y<8&&map[y][x]!=side;y++) start=y;
			for (;y<8&&map[y][x]==side;y++) end=y;
			if (start>=8)
				break;

			if (!(start!=-1 && end!=7 && ((map[start][x]==rival && map[y][x]!=rival)||(map[start][x]!=rival && map[y][x]==rival))))
				num += y-start;
		}
	}

	int nx = 0,ny = 7;
	int sx=0,sy=0,ex=0,ey=0;
	for (y=0;y<8;y++)
	{
		nx=0;
		ny=y;
		sx=-1;
		if (map[ny][0]==side)
			num += 4;

		while (ny<8)
		{
			for(;ny<8&&map[ny][nx]!=side;nx++,ny++){sx=nx;sy=ny;}
			for(;ny<8&&map[ny][nx]==side;nx++,ny++){ex=nx;ey=ny;}
			if (sy>=8)break;
			
			if (!(sx!=-1 && ey!=7 && ((map[sy][sx]!=rival && map[ny][nx]==rival) || (map[sy][sx]==rival && map[ny][nx]!=rival))))
				num += ny-sy;
		}
		if (map[7][y] == side) 
			num+= 4;
	}

	if (map[0][0]==side)
		num+=4;
	if (map[7][7]==side)
		num+=4;

	for (x=1;x<8;x++)
	{
		nx=x;
		ny=0;
		sy=-1;
		if (map[0][nx]==side)
			num += 4;

		while (nx<8)
		{
			for(;nx<8&&map[ny][nx]!=side;nx++,ny++){sx=nx;sy=ny;}
			for(;nx<8&&map[ny][nx]==side;nx++,ny++){ex=nx;ey=ny;}
			if (sx>=8)break;

			if (!(sy!=-1 && ex!=7 && ((map[sy][sx]!=rival && map[ny][nx]==rival) || (map[sy][sx]==rival && map[ny][nx]!=rival))))
					num += nx-sx;
		}
		if (map[x][7]==side)num+=4;
	}

	for (x=7;x>=0;x--)
	{
		nx=x;
		ny=0;
		sy=-1;
		if (map[0][nx]==side)num += 4;
		while (nx>=0)
		{
			for(;nx>=0&&map[ny][nx]!=side;nx--,ny++){sx=nx;sy=ny;}
			for(;nx>=0&&map[ny][nx]==side;nx--,ny++){ex=nx;ey=ny;}
			if (sx > 0)break;
			 
			if (!(sy!=-1 && ex!=0 && ((map[sy][sx]==rival && map[ny][nx]!=rival) || (map[sy][sx]!=rival && map[ny][nx]==rival))))
				num += sx-nx;
		}
		if(map[x][0]==side)num+=4;
	}

	if (map[0][7]==side)num+=4;
	if (map[7][0]==side)num+=4;
	for (x=1;x<8;x++)
	{
		nx=x;
		ny=7;
		sy=-1;
		if (map[7][nx]==side)num += 4;
		while (nx<8)
		{
			for(;nx<8&&map[ny][nx]!=side;nx++,ny--){sx=nx;sy=ny;}
			for(;nx<8&&map[ny][nx]==side;nx++,ny--){ex=nx;ey=ny;}
			if (sy>7) break;

			if (!(sy!=-1 && ex!=7 && ((map[sy][sx]==rival && map[ny][nx]!=rival) || (map[sy][sx]!=rival && map[ny][nx]==rival))))
				num += nx-sx;
		}
		if (map[x][7]==side)num += 4;
	}

	return num;
}

int COthello::GetBest(INT8 (&map)[8][8], INT8 side)
{
	if (IsStart(map))
		return GetBest2(map, side);
	else
		return GetBest1(map, side);
}

bool COthello::IsStart(INT8 (&map)[8][8]) const
{
	int spare = 0;
	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)
			if (map[i][j] == xtl::CHESS_NONE || map[i][j] == xtl::CHESS_TO)
				spare++;

	return spare > 12;
}

int COthello::GetAlphaBeta(INT8 (&map)[8][8],INT8 side, int depth, int alpha, int beta, bool isMine)
{
	Draw();
	int value = GetBest(map, side);

	if (depth <= 0 || value == EndGame)
		return value;

	INT8 tempMap[8][8], temp[8][8], ret[8][8];
	xtl::SetArray(temp, map);
	int best = value;

	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)		//i----y,	j----x
		{
			if (temp[i][j] == xtl::CHESS_TO)
			{
				xtl::SetArray(tempMap, temp);
				tempMap[i][j] = side;
				ClearNextPos(tempMap);
				Reverse(tempMap, j, i, side);

				xtl::SetArray(ret, tempMap);

				isMine = !isMine;
				value = GetAlphaBeta(tempMap, -side, depth - 1, alpha, beta, isMine);
				if (value == NoStep)
				{
					isMine = !isMine;
					value = GetAlphaBeta(tempMap, side, depth - 1, alpha, beta, isMine);
					if (value == NoStep)
						return EndGame;
				}

				if (isMine)
				{
					if (value < beta)
					{
						beta = value;
						best = beta;
						xtl::SetArray(map, ret);Draw();
					}
					else
						return beta;
				}
				else
				{
					if(value > alpha)
					{

					  alpha = value;
					  best = alpha;
					  xtl::SetArray(map, ret);
					  Draw();
					}
					else
						return alpha;
				}
			}
		}

	return best;
}


