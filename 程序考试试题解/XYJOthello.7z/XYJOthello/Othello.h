#pragma once
#include "MyCDC.h"
#include "DataStruct.h"

#include <string>
using namespace std;


enum State
{
	MaxAlpha = -2000,
	MinBeta = 2000,
	NoStep = 2001,
	EndGame = 2002
};


class COthello
{
public:
	COthello(void);
	virtual ~COthello(void);

	virtual void SetDC(CDC* pDC);
	virtual void LoadImage(void);
	virtual void InitGame(void);

	virtual void Draw(void);
	void DrawPane(INT8 (&map)[8][8], int x, int y, INT8 side);


	virtual bool GetNextPos(INT8 (&map)[8][8], INT8 side);
	virtual void ClearNextPos(INT8 (&map)[8][8]);
	virtual void PutDownQiZi(int x, int y, INT8 side);
	virtual bool PutDownQiZi(int x, int y,INT8& side, wstring& strInfo);
	virtual bool PutDownQiZiWithAI(INT8 (&map)[8][8], INT8& side, wstring& strInfo);
	void PutFirstBlackQiZiWithAI(void);
	virtual bool CanPutQiZi(INT8 (&map)[8][8],int x, int y, INT8 side);
	virtual int  JudgePutDownQiZi(INT8 (&map)[8][8], int x, int y, INT8 side, xtl::ArrayPos& arrToPos);
	virtual bool JudgePutDownQiZi(INT8 (&map)[8][8], int x, int y, INT8 side);
	bool HasPane(void) const;
	bool HasSpace(void) const;
	bool IsStart(INT8 (&map)[8][8]) const;
	void Reverse(INT8 (&map)[8][8], int x, int y, INT8 side);

	virtual void GetInfo(wstring& strInfo);
	virtual INT8 WhoWin(void);

	 int GetBest1(INT8 (&map)[8][8], INT8 side); //�վֹ�ֵ����
	 int GetBest2(INT8 (&map)[8][8], INT8 side);//�оֹ�ֵ����
	 int GetBest(INT8 (&map)[8][8], INT8 side);//��������
	 int GetAlphaBeta(INT8 (&map)[8][8],INT8 side, int depth, int alpha, int beta, bool isMine = true);

	 inline bool IsPlaying(void) {return m_doing && HasSpace();}
	 inline void SetGameMode(bool bAI = true){m_isAI = bAI;}
	 inline void SetLevel(int level){m_level = level;}
	 inline int GetLevel(void){return m_level;}
	 inline void SetGame(bool start = true){m_doing = start;}
	 inline bool isAI(void)const{return m_isAI;}
	 inline void SetSide(INT8 side){m_side = side;}

private:
	CDC* m_pDC;
	CMyCDC m_chess;
	CMyCDC m_qiziBlack;
	CMyCDC m_qiziWhite;
	CMyCDC m_qiziTo;
	CMyCDC m_qiziMask;

	xtl::ArrayPos m_whitePos;
	xtl::ArrayPos m_blackPos;
	xtl::ArrayPos m_toPos;

	INT8 m_side;
	int m_level;

	INT8 m_map[8][8];

	bool m_doing;
	bool m_isAI;
};
