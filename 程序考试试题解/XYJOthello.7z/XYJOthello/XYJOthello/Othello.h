#pragma once
#include "MyCDC.h"
#include "DataStruct.h"

enum State
{
	MaxAlpha = -2000,
	MinBeta = 2000,
	NoStep = 2001,
	EndGame = 2002
};

class COthello
{
public:
	COthello(void);
	virtual ~COthello(void);

	virtual void SetDC(CDC* pDC);
	virtual void LoadImage(void);

	virtual void Draw(void);
	virtual void DrawPane(int x, int y, INT8 side);

	virtual void InitGame(void);

	virtual bool GetNextPos(INT8 (&map)[8][8], INT8 side, bool redraw = false);
	virtual void ClearNextPos(INT8 (&map)[8][8]);
	virtual void PutDownQiZi(int x, int y);
	virtual void PutDownQiZi(int x, int y, INT8 side, bool draw = true);
	virtual bool CanPutQiZi(int x, int y, INT8 side);
	virtual int  JudgePutDownQiZi(int x, int y, INT8 side, xtl::ArrayPos& arrToPos);
	virtual bool JudgePutDownQiZi(int x, int y, INT8 side);
	virtual bool HasPane(void) const;
	virtual bool IsStart(INT8 (&map)[8][8]) const;
	virtual void Reverse(int x, int y, INT8 side);

	virtual void GetInfo(CString& strInfo);
	virtual INT8 WhoTurn() const;
	virtual INT8 WhoWin(void);

	 int GetBest1(INT8 (&map)[8][8], INT8 side); //�վֹ�ֵ����
	 int GetBest2(INT8 (&map)[8][8], INT8 side);//�оֹ�ֵ����
	 int GetBest(INT8 (&map)[8][8], INT8 side);
	 int GetAlphaBeta(INT8 (&map)[8][8],INT8 side, int depth, int alpha, int beta);
private:
	CDC* m_pDC;
	CMyCDC m_chess;
	CMyCDC m_qiziBlack;
	CMyCDC m_qiziWhite;
	CMyCDC m_qiziTo;
	CMyCDC m_qiziMask;

	xtl::ArrayPos m_whitePos;
	xtl::ArrayPos m_blackPos;
	xtl::ArrayPos m_toPos;

	INT8 m_side;

	INT8 m_map[8][8];
	INT8 m_quit;

	bool m_doing;
};
