//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by XYJOthello.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_XYJOTHELLO_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDR_MENU                        129
#define IDB_CHESS                       130
#define IDB_BLACK                       131
#define IDB_MASK                        133
#define IDI_ICON1                       134
#define IDI_CANCEL                      134
#define IDB_WHITE                       135
#define IDB_CANPLACE                    136
#define IDC_INFO                        1000
#define IDC_TURN                        1001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
