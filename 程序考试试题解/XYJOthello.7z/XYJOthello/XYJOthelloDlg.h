// XYJOthelloDlg.h : ͷ�ļ�
//

#pragma once


#include "afxwin.h"

class COthello;
// CXYJOthelloDlg �Ի���
class CXYJOthelloDlg : public CDialog
{
// ����
public:
	CXYJOthelloDlg(CWnd* pParent = NULL);	// ��׼���캯��
	~CXYJOthelloDlg();

// �Ի�������
	enum { IDD = IDD_XYJOTHELLO_DIALOG };
public:

	virtual void UpdateInfo(CString& str);

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
	afx_msg void OnPtop();
	afx_msg void OnPtom();
	afx_msg void OnBlack();
	afx_msg void OnWhite();
	afx_msg void OnRestart();
	afx_msg void OnExit();
	afx_msg void OnPrimary();
	afx_msg void OnIntermediate();
	afx_msg void OnStop();
	afx_msg void OnStart();
	afx_msg void OnExplain();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);


protected:
	HICON m_hIcon;

private:
	COthello *m_pGame;
	CStatic m_info;
	CStatic m_turn;
	INT8 m_side;
	bool m_bAI;	
	CMenu* m_pMenu;
};
