//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by XYJOthello.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_XYJOTHELLO_DIALOG           102
#define IDR_MENU                        129
#define IDB_CHESS                       130
#define IDB_BLACK                       131
#define IDB_MASK                        133
#define IDI_ICON1                       134
#define IDB_WHITE                       135
#define IDB_CANPLACE                    136
#define IDI_ICON2                       138
#define IDI_APP                         138
#define IDC_INFO                        1000
#define IDC_TURN                        1001
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_32774                        32774
#define ID_32775                        32775
#define ID_PtoP                         32776
#define ID_PtoM                         32777
#define ID_Black                        32778
#define ID_White                        32779
#define ID_32780                        32780
#define ID_32781                        32781
#define ID_32782                        32782
#define ID_Start                        32783
#define ID_32784                        32784
#define ID_32785                        32785
#define ID_32786                        32786
#define ID_32787                        32787
#define ID_ReStart                      32788
#define ID_Exit                         32789
#define ID_Primary                      32790
#define ID_Intermediate                 32791
#define ID_32792                        32792
#define ID_Stop                         32793
#define ID_32794                        32794
#define ID_32795                        32795
#define ID_Explain                      32796

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32797
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
